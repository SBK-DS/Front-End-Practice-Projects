const hamburger = document.querySelector('.hamburger')
const navlink = document.querySelector('.nav-links')
const links = document.querySelectorAll('.nav-links li')

console.log(links)

hamburger.addEventListener('click', () => {
    navlink.classList.toggle('open');
    links.forEach(temp => {
        temp.classList.toggle('hi');
    })
})