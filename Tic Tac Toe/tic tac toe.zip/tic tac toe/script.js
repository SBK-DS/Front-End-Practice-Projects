// Javascript code is broken into 4 sections

// 1) Basic setup
// 2) Determine winner
// 3) Basic AI and winner notification
// 4) Minimax algorithm

// 1) Basic setup ---> 


var origBoard; // Array top keep track of what's inside in each square of the board
const huPlayer = '0'; // Human Player
const aiPlayer = 'x'; // Ai player
const winCombos = [
    [0,1,2],
    [3,4,5],
    [6,7,8],
    [0,3,6],
    [1,4,7],
    [2,5,8],
    [0,4,8],
    [6,4,2]
] // Array to show the winning combination

const cells = document.querySelectorAll('.cell') // Getting all the cells
startGame();


function startGame() {
    document.querySelector('.endgame').style.display = 'none'
    origBoard = Array.from(Array(9).keys()); // Create an Array of length 9. Do console.log() to see
    
    for(let i=0; i<cells.length; i++)
    {
        cells[i].innerText = ''; // Sets all the previous mark to ''
        cells[i].style.removeProperty('background-color'); // Remove the background color for the winning boxes
        cells[i].addEventListener('click', turnClick, false) // Add Eventlistener to its previous state
    }
}

function turnClick(square) {

    if(typeof(origBoard[square.target.id]) == 'number')
    {
        turn(square.target.id, huPlayer) // We didn't go directly to turn function because this function is suppose to be called by human only 
        if(!checkTie()) // Checking if all the cells are clicked or not
        {
            turn(bestSpot(), aiPlayer) // If match is not tie, Aiplayer will play and return the best spot
        }
    }
}

// Printing the value on user clicking
function turn(squareId, player) {
    origBoard[squareId] = player;
    document.getElementById(squareId).innerText = player;

    // Determine winner
    let gameWon = checkWin(origBoard, player)
    if(gameWon)
    {
        gameOver(gameWon)
    }
}


// Creating Determine function
function checkWin(board, player) {
    let plays = board.reduce((a, e, i) => 
        (e === player) ? a.concat(i): a, []) // Find all the places on board that have already being played
    let gameWon = null;
    for(let [index, win] of winCombos.entries()) // Getting winCombos element as key,value pair
    {
        if(win.every(elem => plays.indexOf(elem) > -1)) // Checks if every element in win is > -1, if yes returns then it returns true
        {
            gameWon = {index: index, player: player} // Returns the winning pattern and player name
            break;
        }
    }

    return gameWon
}

function gameOver(gameWon)
{
    for(let index of winCombos[gameWon.index]) // Loop through the winning patter
    {
        document.getElementById(index).style.backgroundColor = gameWon.player == huPlayer ? "blue":"red"; // Color the background of cells

    }
    for(var i=0; i< cells.length; i++)
    {
        cells[i].removeEventListener('click', turnClick, false) // Remove the event listener from every cell
    }

    declareWinner(gameWon.player == huPlayer ? "You Win!":"You Lose!")
}

function declareWinner(who) {
    document.querySelector(".endgame").style.display = 'block';
    document.querySelector('.endgame .text').innerText = who;
}

function emptySquares() {
    return origBoard.filter(s => typeof(s) == 'number') // Checks and return list of empty squares available
}

function bestSpot() {
    return minimax(origBoard, aiPlayer).index;  // Returns the index of best spot after Ai testing
}

function checkTie() {
    if(emptySquares().length == 0)
    {
        for(let i=0; i<cells.length; i++)
        {
            cells[i].style.backgroundColor = 'green';
            cells[i].removeEventListener('click', turnClick, false)
        }
        declareWinner("Tie Game!");
        return true;
    }
    return false;
}


// Creating minimax function - AI based

function minimax(newBoard, player) {
    var availSpots = emptySquares() // Getting the number of available spots

    // Now we check for terminal states, meaning If someone wins and return the value accordingly

    if(checkWin(newBoard, huPlayer))
    {
        return {score: -10}; // If player wins, we would return -10 value
    }
    else if(checkWin(newBoard, aiPlayer))
    {
        return {score: 10}; // If AI wins we should return = 20
    }
    else if(availSpots.length === 0)
    {
        return {score: 0}; // The game is resulted in a Tie
    }

    // We need to collect the score from each of the empty spots to evaluate later

    var moves = [];
    for (var i=0; i<availSpots.length; i++) // Looping through empty spots
    {
        var move = {};
        move.index = newBoard[availSpots[i]] // Set index no of empty spot that was stored as a number in origBoard to the index property of move object
        newBoard[availSpots[i]] = player // Set the emoty spot on the new board to the current player.
        if(player == aiPlayer)
        {
            var result = minimax(newBoard, huPlayer) // Call the minimax function with the other player and the newly changed new board 
            move.score = result.score // Store the object resulted from minimax function call that includes a score property, to the score property of the move object 
        }
        else
        {
            var result = minimax(newBoard, aiPlayer) // If the minimax function doesn't find the terminal state, it keeps recursively going level by level deeper into the game
            move.score = result.score // This recursion happens until it reaches a terminal state and returns a score one level up

        }

        // Finally minimax resets newboard to what it was before and pushes the move object to the moves array

        newBoard[availSpots[i]] = move.index;
        moves.push(move)
    }

    // Now we need to evaluate the best position

    var bestMove;
    if(player == aiPlayer)
    {
        var bestScore = -10000; // It should choose the move with the highest score when AI is playing and Lowest score if the human is playing
        for(var i=0; i<moves.length; i++)
        {
            if(moves[i].score > bestScore) // If a move has a higher score than best score, the algorithm stores that move
            {
                bestScore = moves[i].score
                bestMove = i
            }
        }
    }
    // Same goes for human player but with opposite values
    else
    {
        var bestScore = 10000; // It should choose the move with the highest score when AI is playing and Lowest score if the human is playing
        for(var i=0; i<moves.length; i++)
        {
            if(moves[i].score < bestScore) // If a move has a higher score than best score, the algorithm stores that move
            {
                bestScore = moves[i].score
                bestMove = i
            }
        }
    }

    return moves[bestMove]
}



